package com.lewolfyt.wolfmod.server.proxy;

public class CommonProxy {
	public void registerRenders() {
		
	}
}
