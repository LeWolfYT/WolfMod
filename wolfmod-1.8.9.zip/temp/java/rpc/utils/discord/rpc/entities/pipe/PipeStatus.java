package com.lewolfyt.wolfmod.client.modules.rpc.utils.discord.rpc.entities.pipe;

public class PipeStatus {

}
